package com.example.ticket_booking_app.model;

public class Ticket {
    private String transport;
    private String from;
    private String to;
    private double price;

    public Ticket(String transport, String from, String to, double price) {
        this.transport = transport;
        this.from = from;
        this.to = to;
        this.price = price;
    }

    // Getters required for TableView
    public String getTransport() { return transport; }
    public String getFrom() { return from; }
    public String getTo() { return to; }
    public double getPrice() { return price; }
}