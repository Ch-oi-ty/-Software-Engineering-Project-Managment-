package com.example.ticket_booking_app.controller;

import com.example.ticket_booking_app.data.UserStore;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class HomeController {
    @FXML
    public void goToBooking(ActionEvent event) throws IOException {
        loadScene(event, "/com/example/ticket_booking_app/booking.fxml", "Book Tickets");
    }

    @FXML
    public void goToMyBookings(ActionEvent event) throws IOException {
        loadScene(event, "/com/example/ticket_booking_app/mybookings.fxml", "My Bookings");
    }

    @FXML
    public void handleLogout(ActionEvent event) throws IOException {
        UserStore.currentUser = null;
        UserStore.currentUserId = 0;
        loadScene(event, "/com/example/ticket_booking_app/login.fxml", "Login");
    }

    private void loadScene(ActionEvent event, String fxmlPath, String title) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource(fxmlPath));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.setTitle(title);
        stage.show();
    }
}