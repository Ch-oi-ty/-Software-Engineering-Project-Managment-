package com.example.ticket_booking_app.controller;

import com.example.ticket_booking_app.data.UserStore;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

public class LoginController {
    @FXML private TextField usernameField;
    @FXML private PasswordField passwordField;
    @FXML private Label errorLabel;

    @FXML
    private void handleLogin(ActionEvent event) {
        String username = usernameField.getText().trim();
        String password = passwordField.getText().trim();

        if (username.isEmpty() || password.isEmpty()) {
            showError("Username and password required");
            return;
        }

        if (UserStore.validateUser(username, password)) {
            redirectTo(event, "/com/example/ticket_booking_app/home.fxml", "Welcome " + username);
        } else {
            showError("Invalid username or password");
        }
    }

    @FXML
    private void goToRegister(ActionEvent event) {
        redirectTo(event, "/com/example/ticket_booking_app/register.fxml", "Register");
    }

    private void showError(String message) {
        errorLabel.setText(message);
        errorLabel.setVisible(true);
    }

    private void redirectTo(ActionEvent event, String fxmlPath, String title) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource(fxmlPath));
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle(title);
            stage.show();
        } catch (IOException e) {
            showError("Failed to load page: " + e.getMessage());
            e.printStackTrace();
        }
    }
}