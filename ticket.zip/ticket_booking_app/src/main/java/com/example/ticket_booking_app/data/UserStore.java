package com.example.ticket_booking_app.data;

import com.example.ticket_booking_app.model.Ticket;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UserStore {
    public static String currentUser;
    public static int currentUserId;

    // Existing validateUser() method
    public static boolean validateUser(String username, String password) {
        String sql = "SELECT id FROM users WHERE username = ? AND password = ?";

        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, username);
            pstmt.setString(2, password);

            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                currentUserId = rs.getInt("id");
                currentUser = username;
                return true;
            }
        } catch (SQLException e) {
            System.err.println("Login failed: " + e.getMessage());
        }
        return false;
    }

    // NEW METHOD: Fetch all available tickets
    public static List<Ticket> getAllTickets() {
        List<Ticket> tickets = new ArrayList<>();
        String sql = "SELECT transport, origin, destination, price FROM tickets";

        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                tickets.add(new Ticket(
                        rs.getString("transport"),
                        rs.getString("origin"),
                        rs.getString("destination"),
                        rs.getDouble("price")
                ));
            }
        } catch (SQLException e) {
            System.err.println("Failed to fetch tickets: " + e.getMessage());
        }
        return tickets;
    }

    // Existing bookTicket() method
    public static boolean bookTicket(Ticket ticket) {
        if (currentUserId <= 0) {
            System.err.println("No user logged in");
            return false;
        }

        String sql = "INSERT INTO bookings (user_id, ticket_id) " +
                "SELECT ?, id FROM tickets " +
                "WHERE transport = ? AND origin = ? AND destination = ?";

        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, currentUserId);
            pstmt.setString(2, ticket.getTransport());
            pstmt.setString(3, ticket.getFrom());
            pstmt.setString(4, ticket.getTo());

            int affectedRows = pstmt.executeUpdate();
            return affectedRows > 0;

        } catch (SQLException e) {
            System.err.println("Booking failed: " + e.getMessage());
            return false;
        }
    }

    // Existing getUserBookings() method
    public static List<Ticket> getUserBookings() {
        List<Ticket> bookings = new ArrayList<>();
        if (currentUserId <= 0) return bookings;

        String sql = "SELECT t.transport, t.origin, t.destination, t.price " +
                "FROM bookings b " +
                "JOIN tickets t ON b.ticket_id = t.id " +
                "WHERE b.user_id = ?";

        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, currentUserId);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                bookings.add(new Ticket(
                        rs.getString("transport"),
                        rs.getString("origin"),
                        rs.getString("destination"),
                        rs.getDouble("price")
                ));
            }
        } catch (SQLException e) {
            System.err.println("Failed to load bookings: " + e.getMessage());
        }
        return bookings;
    }
}