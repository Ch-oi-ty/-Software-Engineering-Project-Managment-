package com.example.ticket_booking_app.controller;

import com.example.ticket_booking_app.data.UserStore;
import com.example.ticket_booking_app.model.Ticket;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;

public class BookingController {
    @FXML private TableView<Ticket> ticketTable;
    @FXML private TableColumn<Ticket, String> transportCol;
    @FXML private TableColumn<Ticket, String> fromCol;
    @FXML private TableColumn<Ticket, String> toCol;
    @FXML private TableColumn<Ticket, Double> priceCol;
    @FXML private Label statusLabel;

    private ObservableList<Ticket> tickets = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        transportCol.setCellValueFactory(new PropertyValueFactory<>("transport"));
        fromCol.setCellValueFactory(new PropertyValueFactory<>("from"));
        toCol.setCellValueFactory(new PropertyValueFactory<>("to"));
        priceCol.setCellValueFactory(new PropertyValueFactory<>("price"));
        refreshTickets();
    }

    private void refreshTickets() {
        tickets.setAll(UserStore.getAllTickets());
        ticketTable.setItems(tickets);
    }

    @FXML
    private void handleBook(ActionEvent event) {
        Ticket selected = ticketTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            statusLabel.setText("Please select a ticket first!");
            return;
        }

        if (UserStore.bookTicket(selected)) {
            statusLabel.setText("Successfully booked ticket!");
            refreshTickets();
        } else {
            statusLabel.setText("Failed to book ticket. Please try again.");
        }
    }

    // Added this missing method
    @FXML
    private void redirectToHome(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("/com/example/ticket_booking_app/home.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.setTitle("Home");
        stage.show();
    }
}