package com.example.ticket_booking_app.data;

import java.sql.*;

public class DatabaseManager {
    private static final String DB_URL = "jdbc:sqlite:ticket_booking.db";

    public static void initializeDatabase() {
        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement()) {

            // Create users table (added this)
            stmt.execute("CREATE TABLE IF NOT EXISTS users (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                    "username TEXT UNIQUE NOT NULL," +
                    "password TEXT NOT NULL)");

            // Create tickets table
            stmt.execute("CREATE TABLE IF NOT EXISTS tickets (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                    "transport TEXT NOT NULL," +
                    "origin TEXT NOT NULL," +
                    "destination TEXT NOT NULL," +
                    "price REAL NOT NULL)");

            // Create bookings table with proper foreign keys
            stmt.execute("CREATE TABLE IF NOT EXISTS bookings (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                    "user_id INTEGER NOT NULL," +
                    "ticket_id INTEGER NOT NULL," +
                    "FOREIGN KEY(user_id) REFERENCES users(id)," +
                    "FOREIGN KEY(ticket_id) REFERENCES tickets(id))");

            // Insert sample tickets if empty
            ResultSet rs = stmt.executeQuery("SELECT COUNT(*) FROM tickets");
            if (rs.getInt(1) == 0) {
                stmt.execute("INSERT INTO tickets (transport, origin, destination, price) VALUES " +
                        "('Bus', 'Dhaka', 'Chittagong', 800)," +
                        "('Train', 'Dhaka', 'Khulna', 600)," +
                        "('Plane', 'Dhaka', 'Sylhet', 2500)");
            }
        } catch (SQLException e) {
            System.err.println("Database initialization failed: " + e.getMessage());
        }
    }

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(DB_URL);
    }
}